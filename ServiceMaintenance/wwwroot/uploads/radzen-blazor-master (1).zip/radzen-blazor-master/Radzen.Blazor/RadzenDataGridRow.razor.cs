namespace Radzen.Blazor
{
    /// <summary>
    /// RadzenDataGridRow.
    /// </summary>
    public partial class RadzenDataGridRow<TItem>
    {
    }
}