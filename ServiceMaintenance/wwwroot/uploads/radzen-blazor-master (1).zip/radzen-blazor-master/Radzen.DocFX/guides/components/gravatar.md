# Gravatar component
This article demonstrates how to use the Gravatar component. Use it to display image from specified email.

```
<RadzenGravatar Email="info@radzen.com" />
```